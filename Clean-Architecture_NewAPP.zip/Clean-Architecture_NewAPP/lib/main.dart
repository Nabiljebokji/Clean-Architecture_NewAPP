import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:new_task_trackre/core/config/theme/app_theme.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/features/home/presentation/pages/home.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/auth/auth_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/auth/auth_state_cubit.dart';
import 'package:new_task_trackre/features/loggin/presentation/pages/login.dart';
import 'package:new_task_trackre/sevice_locator.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarBrightness: Brightness.light,
    systemNavigationBarColor: Colors.black,
  ));

  await dotenv.load(fileName: Environment.fileName);

  setupServiceLocator();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual,
        overlays: [SystemUiOverlay.bottom]);
    return BlocProvider(
      create: (context) => AuthStateCubit()..appStarted(),
      child: MaterialApp(
          theme: AppTheme.appTheme,
          debugShowCheckedModeBanner: false,
          home: BlocBuilder<AuthStateCubit, AuthState>(
            builder: (context, state) {
              if (state is Authenticated) {
                return HomePage();
              }
              if (state is UnAuthenticated) {
                return LogginPage();
              }
              return const Scaffold(
                body: Center(child: CircularProgressIndicator()),
              );
            },
          )),
    );
  }
}
