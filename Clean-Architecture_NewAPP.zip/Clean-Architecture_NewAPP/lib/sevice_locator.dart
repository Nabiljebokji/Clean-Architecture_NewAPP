import 'package:get_it/get_it.dart';
import 'package:new_task_trackre/core/network/dio_client.dart';
import 'package:new_task_trackre/features/home/data/repository/home.dart';
import 'package:new_task_trackre/features/home/domain/repository/home.dart';
import 'package:new_task_trackre/features/home/domain/usecases/get_home_list_usecase.dart';
import 'package:new_task_trackre/features/home/domain/usecases/is_role_valid_usecace.dart';
import 'package:new_task_trackre/features/loggin/data/repository/auth.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_api_service.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_local_service.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/check_if_base_url_empty.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/is_logged_in.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/login_button.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/logout.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/qr_code_reader.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/signup.dart';

final sl = GetIt.instance;

void setupServiceLocator() {
  sl.registerSingleton<DioClient>(DioClient());

  //Services
  sl.registerSingleton<AuthApiService>(AuthApiServiceImp());

  sl.registerSingleton<AuthLocalService>(AuthLocalServiceImpl());

  //Repositories
  sl.registerSingleton<AuthRepository>(AuthRepositorImpl());

  sl.registerSingleton<HomeRepository>(HomeRepositorImpl());

  //Usecases
  sl.registerSingleton<SignUpUseCase>(SignUpUseCase());

  sl.registerSingleton<IsLoggedInUseCase>(IsLoggedInUseCase());

  sl.registerSingleton<LogoutUseCase>(LogoutUseCase());

  sl.registerSingleton<QrCodeReaderUseCase>(QrCodeReaderUseCase());

  sl.registerSingleton<CheckIfBaseUrlEmptyUseCase>(
      CheckIfBaseUrlEmptyUseCase());

  sl.registerSingleton<LoginButtonUseCase>(LoginButtonUseCase());

  sl.registerSingleton<IsRoleValidUseCase>(IsRoleValidUseCase());

  sl.registerSingleton<GetHomeListUsecase>(GetHomeListUsecase());
}
