// dotenv

import 'package:flutter_dotenv/flutter_dotenv.dart';

class Environment {
  static String get fileName => ".env";

  static String get tempBaseName => dotenv.get("TEMPBASENAME");

  static String get baseName => dotenv.get("BACKENDBASENAME");

  static String get userName => dotenv.get("USERNAME");

  static String get passWord => dotenv.get("PASSWORD");

  static String get fakeName => dotenv.get("FAKENAME");

  static String get fakePassWord => dotenv.get("FAKEPASSWORD");

  static String get refreshTokenURL => dotenv.get("REFRESH_TOKEN");

  static String get accessToken => dotenv.get("ACCESSTOKEN");

  static String get permissions => dotenv.get("PERMISSIONS");

  static String get userRole => dotenv.get("USERROLE");

  static String get refreshToken => dotenv.get("REFRESHTOKEN");

  static String get userId => dotenv.get("USERID");

  static String get expiration => dotenv.get("EXPIRATION");

  static String get customerId => dotenv.get("CUSTOMERID");

  static String get apiUrl => dotenv.get("APIURL");

  static String get sabitKurumId => dotenv.get("SABITKURUMID");

  static String get rememberName => dotenv.get("REMEMBERNAME");

  static String get rememberPass => dotenv.get("REMEMBERPASS");

  static String get getUserPermissionURL => dotenv.get("GetUserPermissions");

  static String get getRolesToUserURL => dotenv.get("GetRolesToUser");

  static String get authLogin => dotenv.get("AUTHLOGIN");

  static String get getPersonnelUserIdListURL =>
      dotenv.get("GetPersonnelUserIdListURL");

  static String get getUserPermissions => dotenv.get("GetUserPermissions");

  static String get getHomeList => dotenv.get("GetHomeList");

  static String get getHomeSubList => dotenv.get("GetHomeSubList");

  static String get getRolesToUser => dotenv.get("GetRolesToUser");

  static String get getStaffList => dotenv.get("GetStaffList");

  static String get getStaffSubList => dotenv.get("GetStaffSubList");

  static String get getBarcodes => dotenv.get("GetBarcodes");

  static String get deleteTaskList => dotenv.get("DeleteTaskList");

  static String get getTaskCompletion => dotenv.get("GetTaskCompletion");

  static String get getTasksList => dotenv.get("GetTasksList");

  static String get getTaskDescriptionaList =>
      dotenv.get("GetTaskDescriptionaList");

  static String get getPersonnelUserIdList =>
      dotenv.get("GetPersonnelUserIdListURL");

  static String get getPersonnelList => dotenv.get("GetPersonnelList");

  static String get getAreaList => dotenv.get("GetAreaList");

  static String get createTaskList => dotenv.get("CreateTaskList");

  static String get getAreaSubList => dotenv.get("GetAreaSubList");

  static String get deleteTaskPersonnelList =>
      dotenv.get("DeleteTaskPersonnelList");

  static String get getprovincesList => dotenv.get("GetprovincesList");

  static String get getdistrictsList => dotenv.get("GetdistrictsList");

  static String get createTaskPersonnelList =>
      dotenv.get("CreateTaskPersonnelList");

  static String get createUser => dotenv.get("CreateUser");

  static String get updateTaskPersonnelList =>
      dotenv.get("UpdateTaskPersonnelList");

  static String get getAllUsers => dotenv.get("GetAllUsers");

  static String get deleteUser => dotenv.get("DeleteUser");

  static String get getRoles => dotenv.get("GetRoles");

  static String get assignRoleToUser => dotenv.get("AssignRoleToUser");

  static String get updatePasswordWithNoResetToken =>
      dotenv.get("UpdatePasswordWithNoResetToken");

  static String get getTaskTemplateList => dotenv.get("GetTaskTemplateList");

  static String get createTaskDescription =>
      dotenv.get("CreateTaskDescription");

  static String get deleteTaskDescription =>
      dotenv.get("DeleteTaskDescription");

  static String get updateTaskDescription =>
      dotenv.get("UpdateTaskDescription");

  static String get updateTaskTemplate => dotenv.get("UpdateTaskTemplate");

  static String get deleteTaskTemplate => dotenv.get("DeleteTaskTemplate");

  static String get createArea => dotenv.get("CreateArea");

  static String get deleteArea => dotenv.get("DeleteArea");

  static String get updateArea => dotenv.get("UpdateArea");

  static String get batchCreateTaskList => dotenv.get("BatchCreateTaskList");

  static String get batchGetTaskCompletion =>
      dotenv.get("BatchGetTaskCompletion");

  // static String get hereApiUrl {
  //   final baseName = dotenv.get("BACKEND_BASENAME");
  //   final apiPath = dotenv.get("BACKEND_API_PATH");
  //   final hereRouteUrl = dotenv.get("HERE_ROUTE_API_PATH");
  //   return "${Uri.parse(baseName).resolve(apiPath)}$hereRouteUrl";
  // }
}
