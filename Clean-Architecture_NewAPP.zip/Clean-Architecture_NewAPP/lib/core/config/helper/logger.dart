// main.dart
import 'dart:developer' as developer;

import 'package:flutter/foundation.dart' show kDebugMode;

class Logger {
  // Blue text
  static void info(String msg) {
    _prinToConsoleInDebug('🙂\x1b[93m $msg\x1B[0m');
  }

// Green text
  static void success(String msg) {
    _prinToConsoleInDebug('🥳\x1b[92m$msg\x1B[0m');
  }

// Yellow text
  static void warning(String msg) {
    _prinToConsoleInDebug('🚀\x1B[95m$msg\x1B[0m');
  }

// Red text
  static void error(String msg) {
    _prinToConsoleInDebug('🔥\x1B[31m$msg\x1B[0m');
  }

  static void _prinToConsoleInDebug(String msg) {
    if (kDebugMode) {
      developer.log(msg);
    }
  }
}
