import 'package:flutter/material.dart';

class AppColors {
  static const blue = Color(0xFF2287c9);
  static const bluesh = Color.fromARGB(155, 34, 134, 201);
  static const yellow = Colors.yellow;
  static const lightYellow = Color.fromARGB(255, 252, 248, 214);
  static const orange = Color.fromARGB(255, 255, 180, 69);
  static const purpole = Color.fromARGB(255, 88, 69, 255);
  static const green = Color.fromARGB(189, 0, 118, 4);
  static const greenish = Color.fromARGB(214, 111, 207, 114);
  static const grey = Color.fromARGB(255, 235, 235, 235);
  static const greyish = Color.fromARGB(255, 238, 238, 238);
  static const black = Color.fromARGB(255, 0, 0, 0);
  static const transparent = Color(0x00000000);
  static const white = Color.fromARGB(255, 255, 255, 255);
  static const darkred = Color(0xffAB0707);
  static const lightRed = Color.fromARGB(251, 250, 202, 197);
  static const lightRed2 = Color.fromARGB(249, 255, 233, 231);
  static const mintGreen = Color.fromARGB(255, 189, 255, 205);
  static const greenish2 = Color(0xffAFFFB5);
  static const avocado = Color(0xFF7BC043);
  static const lightGreen2 = Color.fromARGB(255, 221, 255, 230);
  static const lightGreen = Color(0xffACFFD4);
  static const lightGrey = Color(0xffF1F1F2);
  // static const lightBlue = Color(0xffA1D6E2);
  static const tealBlue = Color(0xFF1995AD);
  static const buttonBlue = Color(0xFF284E57);
  static const lightBlue = Color.fromARGB(255, 155, 227, 227);
  static const webDarkBlue = Color(0xFF549EBB);
  static const webBlue = Color(0xFFc4dfdf);
  static const logoColor = Color(0xFF306C88);
  static const lightgrey = Color.fromARGB(255, 240, 240, 240);
}
