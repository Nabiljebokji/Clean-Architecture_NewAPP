class AppImages {
// SVG
  static String svgPath = "assets/images/svg";

  static String kardelenLogo = "$svgPath/KardelenLogo.svg";
  static String kardelenYazilim = "$svgPath/Kardelenyazilim.svg";

// JPG
  static String imageJpgPath = "assets/images/jpg";

  static String orhun = "$imageJpgPath/orhun.jpg";

// PNG
  static String imagePngPath = "assets/images/png";

  static String tree = '$imagePngPath/tree.png';
  static String qrCode = '$imagePngPath/qrCode.png';
  static String man = '$imagePngPath/man.png';
  static String woman = '$imagePngPath/woman.png';
  static String logo = '$imagePngPath/logo.png';

  // JSON
  static const String rootLottie = "assets/lottie";

  static const String ecommerce = "$rootLottie/ecommerce.json";
  static const String loading = "$rootLottie/loading1.json";
  static const String loading2 = "$rootLottie/loading2.json";
  static const String offline = "$rootLottie/offline.json";
  static const String noData = "$rootLottie/nodata.json";
  static const String server = "$rootLottie/server.json";
}
