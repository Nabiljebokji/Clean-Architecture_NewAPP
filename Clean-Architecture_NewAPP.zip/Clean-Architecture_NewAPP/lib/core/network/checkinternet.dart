import 'dart:io';
import 'package:flutter/material.dart';

checkInternet() async {
  try {
    var result = await InternetAddress.lookup("google.com");
    debugPrint(result.toString());

    if (result.isNotEmpty && result[0].rawAddress.isNotEmpty) {
      return true;
    }
  } on SocketException catch (e) {
    debugPrint(e.toString());

    return false;
  }
}
