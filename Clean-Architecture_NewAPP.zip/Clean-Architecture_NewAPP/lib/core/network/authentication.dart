import 'package:dio/dio.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/core/config/helper/logger.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Authentication extends Interceptor {
  Authentication();

  final Dio _dio = Dio();

  Future<String?> _getToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var token = sharedPreferences.getString(Environment.accessToken);
    return '$token';
  }

  // Refresh token logic (if needed)
  Future<String?> _refreshToken() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    var name = sharedPreferences.getString(Environment.fakeName);
    var pass = sharedPreferences.getString(Environment.fakePassWord);
    var baseName = sharedPreferences.getString(Environment.baseName);
    final Response response = await _dio.post(
      "$baseName${Environment.authLogin}",
      data: {
        'usernameOrEmail': name,
        'password': pass,
      },
    );
    if (response.statusCode == 200) {
      Loggers.warning("==============200==============");

      sharedPreferences.setString(
          Environment.accessToken, response.data["token"]["accessToken"]);
      return '${response.data["token"]["accessToken"]}';
    } else {
      Loggers.warning("==============warning==============");
      return null;
    }
    // return '${response.data["token"]["accessToken"]}';
  }

  @override
  Future onRequest(
      RequestOptions options, RequestInterceptorHandler handler) async {
    // Get token from secure storage or any global method
    String? token = await _getToken();

    // Add the token to headers if available
    if (token != null) {
      options.headers['Authorization'] = 'Bearer $token';
    }

    // Proceed with the request
    return handler.next(options);
  }

  @override
  Future onResponse(
      Response response, ResponseInterceptorHandler handler) async {
    // Handle the successful response here if needed
    return handler.next(response);
  }

  @override
  Future onError(DioError err, ErrorInterceptorHandler handler) async {
    // If the error is due to unauthorized access (status code 401), handle it
    if (err.response?.statusCode == 401) {
      try {
        Loggers.warning("==============warning==============");
        // Attempt to refresh the token
        String? newToken = await _refreshToken();

        if (newToken != null) {
          // Save the new token to secure storage
          // await secureStorage.write(key: 'token', value: newToken);

          // Retry the original request with the new token
          final options = err.requestOptions;
          options.headers['Authorization'] = 'Bearer $newToken';

          // Retry the request with the new token
          final response = await _dio.fetch(options);
          return handler.resolve(response);
        }
      } catch (e) {
        // Handle token refresh failure (e.g., log out the user)
        print('Token refresh failed: $e');
      }
    }

    // If not an authentication issue, continue with the error
    return handler.next(err);
  }
}
