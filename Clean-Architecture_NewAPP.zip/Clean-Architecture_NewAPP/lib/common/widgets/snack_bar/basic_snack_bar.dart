import 'package:flutter/material.dart';
import 'package:new_task_trackre/core/constants/colors/app_colors.dart';

customSnackBar({
  required BuildContext context,
  String? title,
  String? body,
  Color? backgroundColor,
  required bool isErrorIcon,
}) {
  return SnackBar(
    content: Row(
      children: [
        isErrorIcon
            ? Icon(Icons.error, color: Colors.red[900])
            : const Icon(Icons.check_circle_outline, color: Colors.green),
        const SizedBox(width: 10),
        Flexible(
            child: Text(body ?? '',
                style: const TextStyle(color: AppColors.black))),
      ],
    ),
    backgroundColor: backgroundColor ?? Colors.white,
    behavior: SnackBarBehavior.floating,
    margin: const EdgeInsets.all(10),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(10),
    ),
    duration: const Duration(seconds: 3),
  );
}
