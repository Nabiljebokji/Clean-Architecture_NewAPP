import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/time_text/time_text_state.dart';

class TimeTextCubitState extends Cubit<TimeTextState> {
  TimeTextCubitState() : super(TimeTextLoading());

  Future<void> getTime(
      DateTime tempDateTime, String? startTime, String? endTime) async {
    String result;
    var dayTemp = DateFormat('dd').format(tempDateTime);
    var monthTemp = DateFormat('MM').format(tempDateTime);
    var yearTemp = DateFormat('yyyy').format(tempDateTime);
    if (startTime!.isNotEmpty && endTime!.isNotEmpty) {
      result =
          "${DateFormat('dd.MM').format(DateFormat("yyyy.M.d").parse(startTime))} - ${DateFormat('dd.MM').format(DateFormat("yyyy.M.d").parse(endTime))}";
    } else if (int.tryParse(dayTemp) == DateTime.now().day &&
        int.tryParse(monthTemp) == DateTime.now().month &&
        int.tryParse(yearTemp) == DateTime.now().year) {
      result = "Bugün";
    } else if (int.tryParse(dayTemp) == DateTime.now().day - 1 &&
        int.tryParse(monthTemp) == DateTime.now().month &&
        int.tryParse(yearTemp) == DateTime.now().year) {
      result = "Dün";
    } else if (int.tryParse(dayTemp) == DateTime.now().day + 1 &&
        int.tryParse(monthTemp) == DateTime.now().month &&
        int.tryParse(yearTemp) == DateTime.now().year) {
      result = "Yarın";
    } else {
      result = DateFormat('dd.MM.yyyy').format(tempDateTime);
    }
    emit(TimeTextLoaded(timeText: result));
  }
}
