abstract class TimeTextState {}

class TimeTextLoading extends TimeTextState {}

class TimeTextLoaded extends TimeTextState {
  final String? timeText;

  TimeTextLoaded({this.timeText});
}

class TimeTextFaliure extends TimeTextState {
  final String errorMessage;

  TimeTextFaliure({required this.errorMessage});
}
