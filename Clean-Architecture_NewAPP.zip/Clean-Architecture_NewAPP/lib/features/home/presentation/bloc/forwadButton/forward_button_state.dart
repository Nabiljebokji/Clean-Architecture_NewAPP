abstract class ForwardButtonState {}

class ForwardButtonInitialState extends ForwardButtonState {}

class ForwardButtonLoaded extends ForwardButtonState {
  final DateTime? tempDateTime;
  final String? startTimeTextFiled;
  final String? endTimeTextFiled;
  final String? startDate;
  final String? endDate;

  ForwardButtonLoaded({
    this.tempDateTime,
    this.startTimeTextFiled,
    this.endTimeTextFiled,
    this.startDate,
    this.endDate,
  });
}
