import 'package:new_task_trackre/features/home/domain/entities/home_list.dart';

abstract class UserRolesState {}

class UserRolesLoading extends UserRolesState {}

class AdminRolesLoaded extends UserRolesState {
  final List<HomeScreenQueryDtoEntity>? homeListEntity;

  AdminRolesLoaded({this.homeListEntity});
}

class WorkerRolesLoaded extends UserRolesState {
  final HomeListEntity? homeListEntity;

  WorkerRolesLoaded({this.homeListEntity});
}

class UserRolesFaliure extends UserRolesState {
  final String errorMessage;

  UserRolesFaliure({required this.errorMessage});
}
