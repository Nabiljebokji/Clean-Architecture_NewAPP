import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/domain/usecases/get_home_list_usecase.dart';
import 'package:new_task_trackre/features/home/domain/usecases/is_role_valid_usecace.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/user_roles/user_roles_state.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class UserRolesCubit extends Cubit<UserRolesState> {
  UserRolesCubit() : super(UserRolesLoading());

  Future<void> isRoleValid(HomeListParams homeListParams) async {
    if (await sl<IsRoleValidUseCase>().call(param: "GetHomeList")) {
      Either result =
          await sl<GetHomeListUsecase>().call(param: homeListParams);
      return result.fold(
        (error) {
          emit(UserRolesFaliure(errorMessage: error.toString()));
        },
        (data) {
          emit(AdminRolesLoaded(homeListEntity: data));
        },
      );
    }
    if (await sl<IsRoleValidUseCase>().call(param: "GetStaffList")) {
      return emit(UserRolesFaliure(errorMessage: "GetStaffList".toString()));
    } else {
      emit(UserRolesFaliure(errorMessage: "Unauthorized"));
    }
  }
}
