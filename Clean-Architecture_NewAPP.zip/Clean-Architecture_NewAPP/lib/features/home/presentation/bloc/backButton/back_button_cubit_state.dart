import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:intl/intl.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/backButton/back_button_state.dart';

class BackButtonCubitState extends Cubit<BackButtonState> {
  BackButtonCubitState() : super(BackButtonInitialState());

  Future<void> subtractDay(DateTime tempDateTime, String? startDateTextFiled,
      String? endDateTextFiled) async {
    // closeLastExpantion(selectedindex, false);

    tempDateTime = tempDateTime.subtract(const Duration(days: 1));

    if (startDateTextFiled!.isNotEmpty && endDateTextFiled!.isNotEmpty) {
      startDateTextFiled = "";
      endDateTextFiled = "";
      tempDateTime = DateTime.now();
    }
    String? startDate = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(
        DateTime(tempDateTime.year, tempDateTime.month, tempDateTime.day, 01,
            00, 00, 00));
    var addOneDay = DateFormat("dd")
        .format(DateTime.tryParse(startDate)!.add(const Duration(days: 1)));
    String? endDate = DateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(
        DateTime(DateTime.now().year, tempDateTime.month,
            int.tryParse(addOneDay)!, 23, 59, 00, 00));
    emit(BackButtonLoaded(
      tempDateTime: tempDateTime,
      startTimeTextFiled: startDateTextFiled,
      endTimeTextFiled: endDateTextFiled,
      startDate: startDate,
      endDate: endDate,
    ));
    // getDate();
    // initService();
  }
}
