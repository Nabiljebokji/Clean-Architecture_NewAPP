abstract class BackButtonState {}

class BackButtonInitialState extends BackButtonState {}

class BackButtonLoaded extends BackButtonState {
  final DateTime? tempDateTime;
  final String? startTimeTextFiled;
  final String? endTimeTextFiled;
  final String? startDate;
  final String? endDate;

  BackButtonLoaded({
    this.tempDateTime,
    this.startTimeTextFiled,
    this.endTimeTextFiled,
    this.startDate,
    this.endDate,
  });
}
