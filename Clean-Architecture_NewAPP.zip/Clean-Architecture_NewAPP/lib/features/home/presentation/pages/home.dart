// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:new_task_trackre/core/constants/colors/app_colors.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/backButton/back_button_cubit_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/backButton/back_button_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/backButton/forward_button_cubit_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/forwadButton/forward_button_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/time_text/time_text_cubit_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/time_text/time_text_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/user_roles/user_roles_cubit_state.dart';
import 'package:new_task_trackre/features/home/presentation/bloc/user_roles/user_roles_state.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final TextEditingController startTimeEditingController =
      TextEditingController();
  final TextEditingController endTimeEditingController =
      TextEditingController();
  String? startDate;
  String? endDate;

  DateTime tempDateTime = DateTime.now();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: scaffoldKey,
      backgroundColor: AppColors.lightgrey,
      appBar: appBar(),
      body: SafeArea(
        child: MultiBlocProvider(
          providers: [
            BlocProvider(
                create: (context) => UserRolesCubit()
                  ..isRoleValid(HomeListParams(
                    startDate: startDate,
                    endDate: endDate,
                  ))),
          ],

          child: BlocBuilder<UserRolesCubit, UserRolesState>(
            builder: (context, state) {
              if (state is UserRolesLoading) {
                return const Center(child: CircularProgressIndicator());
              }
              if (state is AdminRolesLoaded) {
                // return Container();
                return ListView.builder(
                    itemCount: state.homeListEntity!.length,
                    itemBuilder: (context, index) {
                      return Card(
                        color: AppColors.white,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                        child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Column(
                            children: [
                              ExpansionTile(
                                // key: index == controller.lastone
                                //     ? const Key("selected")
                                //     : Key(index.toString()),
                                // initiallyExpanded:
                                //     index == controller.selectedindex,
                                onExpansionChanged: (value) async {
                                  // controller.closeLastExpantion(index, value);
                                  // controller.getExpansionCardData(index);
                                },
                                textColor: AppColors.black,
                                iconColor: AppColors.logoColor,
                                collapsedIconColor: AppColors.black,
                                collapsedTextColor: AppColors.black,
                                backgroundColor: AppColors.lightGrey,
                                childrenPadding: const EdgeInsets.all(5),
                                title: const Text(
                                  // "${controller.cardNamesList![index]}",
                                  "",
                                  style: TextStyle(
                                      // color: AppColors.logoColor,
                                      fontWeight: FontWeight.w700),
                                ),
                                //   children: [
                                //     (controller.tempList.isNotEmpty &&
                                //             controller.tempList != [])
                                //         ? Container(
                                //             height: Get.height * 0.5,
                                //             child: ListView.builder(
                                //                 itemCount:
                                //                     controller.tempList.length,
                                //                 itemBuilder: (context, index) {
                                //                   return InkWell(
                                //                     splashColor:
                                //                         AppColors.logoColor,
                                //                     onTap: () {
                                //                       Get.bottomSheet(
                                //                         staffSubList(controller
                                //                             .tempList[index]
                                //                             .taskListId),
                                //                         isScrollControlled: true,
                                //                       ).whenComplete(() {
                                //                         homeController.update();
                                //                       });
                                //                     },
                                //                     child: Material(
                                //                       color:
                                //                           AppColors.transparent,
                                //                       child: Card(
                                //                         color: AppColors.white,
                                //                         shape:
                                //                             RoundedRectangleBorder(
                                //                                 borderRadius:
                                //                                     BorderRadius
                                //                                         .circular(
                                //                                             10)),
                                //                         child: Slidable(
                                //                           endActionPane:
                                //                               ActionPane(
                                //                             motion:
                                //                                 ScrollMotion(),
                                //                             extentRatio: 0.3,
                                //                             children: [
                                //                               SlidableAction(
                                //                                 autoClose: true,
                                //                                 borderRadius: const BorderRadius.only(
                                //                                     bottomRight: Radius
                                //                                         .circular(
                                //                                             10),
                                //                                     topRight: Radius
                                //                                         .circular(
                                //                                             10)),
                                //                                 onPressed:
                                //                                     (context) {
                                //                                   Get.dialog(
                                //                                       DeleteDialog(
                                //                                     onPressed:
                                //                                         () {
                                //                                       homeController.deleteTaskListService(controller
                                //                                           .getTempList[
                                //                                               index]
                                //                                           .taskListId);
                                //                                       Get.back();
                                //                                     },
                                //                                   ));
                                //                                 },
                                //                                 backgroundColor:
                                //                                     AppColors
                                //                                         .darkred,
                                //                                 foregroundColor:
                                //                                     Colors.white,
                                //                                 icon: Icons
                                //                                     .delete_forever_outlined,
                                //                                 label: 'Sil',
                                //                               ),
                                //                             ],
                                //                           ),
                                //                           child: Padding(
                                //                             padding:
                                //                                 const EdgeInsets
                                //                                     .all(10.0),
                                //                             child: Column(
                                //                               children: [
                                //                                 // CardList(
                                //                                 //     title: "adi soyadi",
                                //                                 //     data: controller
                                //                                 //                 .getTempList[
                                //                                 //                     index]
                                //                                 //                 .topAreaName ==
                                //                                 //             null
                                //                                 //         ? ""
                                //                                 //         : "${controller.getTempList[index].personnelName} ${controller.getTempList[index].personnelSurname}"),
                                //                                 const SizedBox(
                                //                                     height: 5),
                                //                                 CardList(
                                //                                     title:
                                //                                         "Bölgeler",
                                //                                     data: controller
                                //                                                 .getTempList[index]
                                //                                                 .topAreaName ==
                                //                                             null
                                //                                         ? ""
                                //                                         : "${controller.getTempList[index].topAreaName}"),
                                //                                 CardList(
                                //                                     title:
                                //                                         "Seçili Bölge",
                                //                                     data: controller
                                //                                                 .getCardList[index]
                                //                                                 .areaName ==
                                //                                             null
                                //                                         ? ""
                                //                                         : "${controller.getTempList[index].areaName}"),
                                //                                 CardList(
                                //                                     title:
                                //                                         "İş Tanımı",
                                //                                     data: controller
                                //                                                 .getCardList[index]
                                //                                                 .taskName ==
                                //                                             null
                                //                                         ? ""
                                //                                         : "${controller.getTempList[index].taskName}"),
                                //                                 CardList(
                                //                                     title:
                                //                                         "Görev Başlangıç Tarihi",
                                //                                     data: controller
                                //                                                 .getTempList[
                                //                                                     index]
                                //                                                 .startDate ==
                                //                                             null
                                //                                         ? ""
                                //                                         : DateFormat('yyyy.MM.dd  kk:mm').format(controller
                                //                                             .getTempList[
                                //                                                 index]
                                //                                             .startDate!)),
                                //                                 CardList(
                                //                                     title:
                                //                                         "Görev Bitiş Tarihi",
                                //                                     data: controller
                                //                                                 .getTempList[
                                //                                                     index]
                                //                                                 .endDate ==
                                //                                             null
                                //                                         ? ""
                                //                                         : DateFormat('yyyy.MM.dd  kk:mm').format(controller
                                //                                             .getTempList[
                                //                                                 index]
                                //                                             .endDate!)),
                                //                               ],
                                //                             ),
                                //                           ),
                                //                         ),
                                //                       ),
                                //                     ),
                                //                   );
                                //                 }),
                                //           )
                                //         // : SizedBox(),
                                //         : const Text("Boş.."),
                                //   ],
                              ),
                            ],
                          ),
                        ),
                      );
                    });
              }
              if (state is WorkerRolesLoaded) {
                return Container();
              }
              if (state is UserRolesFaliure) {
                return Text(state.errorMessage.toString());
              }
              return Container();
            },
          ),
          // ),
        ),
      ),
    );
  }

  PreferredSizeWidget appBar() {
    return AppBar(
      backgroundColor: AppColors.white,
      elevation: 1,
      title: appBarTitle(),
      actions: [
        Padding(
          padding: const EdgeInsets.all(4.0),
          child: filterIcon(),
        ),
      ],
      leading: leadingDrawer(),
    );
  }

  Widget appBarTitle() {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
            create: (context) => TimeTextCubitState()
              ..getTime(tempDateTime, startTimeEditingController.text,
                  endTimeEditingController.text)),
        BlocProvider(create: (context) => ForwardButtonCubitState()),
        BlocProvider(create: (context) => BackButtonCubitState()),
        BlocProvider(create: (context) => UserRolesCubit()),
      ],
      child: MultiBlocListener(
        listeners: [
          BlocListener<ForwardButtonCubitState, ForwardButtonState>(
            listener: (context, state) {
              if (state is ForwardButtonLoaded) {
                tempDateTime = state.tempDateTime!;
                startTimeEditingController.text = state.startTimeTextFiled!;
                endTimeEditingController.text = state.endTimeTextFiled!;
                startDate = state.startDate;
                endDate = state.endDate;
                context.read<TimeTextCubitState>().getTime(
                      tempDateTime,
                      startTimeEditingController.text,
                      endTimeEditingController.text,
                    );
              }
            },
          ),
          BlocListener<BackButtonCubitState, BackButtonState>(
            listener: (context, state) {
              if (state is BackButtonLoaded) {
                tempDateTime = state.tempDateTime!;
                startTimeEditingController.text = state.startTimeTextFiled!;
                endTimeEditingController.text = state.endTimeTextFiled!;
                startDate = state.startDate;
                endDate = state.endDate;
                context.read<TimeTextCubitState>().getTime(
                      tempDateTime,
                      startTimeEditingController.text,
                      endTimeEditingController.text,
                    );
                context.read<UserRolesCubit>().isRoleValid(HomeListParams(
                      startDate: startDate,
                      endDate: endDate,
                    ));
              }
            },
          ),
        ],
        child: Builder(builder: (context) {
          return Row(
            children: [
              backIconButton(context),
              timeText(),
              forwardIconButton(context),
            ],
          );
        }),
      ),
    );
  }

  Widget backIconButton(BuildContext context) {
    return Expanded(
      flex: 1,
      child: IconButton(
        onPressed: () async {
          await context.read<BackButtonCubitState>().subtractDay(
                tempDateTime,
                startTimeEditingController.text,
                endTimeEditingController.text,
              );
        },
        icon: const Icon(
          Icons.arrow_back_rounded,
          color: AppColors.logoColor,
          size: 26,
        ),
      ),
    );
  }

  Widget forwardIconButton(BuildContext context) {
    return Expanded(
      flex: 1,
      child: IconButton(
        onPressed: () async {
          await context.read<ForwardButtonCubitState>().addDay(
                tempDateTime,
                startTimeEditingController.text,
                endTimeEditingController.text,
              );
        },
        icon: const Icon(
          Icons.arrow_forward_rounded,
          color: AppColors.logoColor,
          size: 26,
        ),
      ),
    );
  }

  Widget timeText() {
    return Expanded(
      flex: 5,
      child: BlocBuilder<TimeTextCubitState, TimeTextState>(
        builder: (context, state) {
          if (state is TimeTextLoading) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (state is TimeTextLoaded) {
            return GestureDetector(
              onTap: () {
                // Get.dialog(calendarDialog(
                //   controller: homeController.appBarTimeController,
                //   value: homeController.dates,
                //   onValueChanged: (value) {
                //     for (var element in value) {
                //       homeController.setDate(
                //           homeController.appBarTimeController, element);
                //     }
                //   },
                // ));
              },
              child: Center(
                child: Text(
                  state.timeText.toString(),
                  style: const TextStyle(color: AppColors.logoColor),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            );
          }
          return Container();
        },
      ),
    );
  }

  Widget leadingDrawer() {
    return Padding(
      padding: const EdgeInsets.all(4.0),
      child: Material(
        color: AppColors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          splashColor: Colors.black,
          onTap: () {
            scaffoldKey.currentState!.openDrawer();
          },
          child: Container(
            decoration: BoxDecoration(
              color: AppColors.logoColor,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(
              Icons.menu_rounded,
            ),
          ),
        ),
      ),
    );
  }

  Widget filterIcon() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4),
      child: Container(
        height: 50,
        width: 50,
        decoration: BoxDecoration(
          color: AppColors.logoColor,
          borderRadius: BorderRadius.circular(10),
        ),
        child: IconButton(
          color: AppColors.white,
          icon: const Icon(Icons.filter_alt_outlined),
          onPressed: () {
            // homeController.clearData();

            // Get.bottomSheet(
            //   filterBottomSheet(),
            //   isScrollControlled: true,
            // ).whenComplete(() {
            //   homeController.update();
            // });
          },
        ),
      ),
    );
  }
}
