import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/features/home/data/models/home_list.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/data/models/personnel_list_params.dart';
import 'package:new_task_trackre/features/home/domain/repository/home.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_api_service.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_local_service.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class HomeRepositorImpl extends HomeRepository {
  @override
  Future<bool> isRoleValid(String? role) async {
    bool isRoleValid = await sl<AuthLocalService>().isRoleValid(role);
    return isRoleValid;
  }

  @override
  Future<Either> getHomeList(HomeListParams? param) async {
    Either result = await sl<AuthApiService>().getHomeList(param);
    return result.fold(
      (error) {
        return Left(error);
      },
      (data) async {
        Either error = await getPersonnelList(PersonnelListParams());

        if (error.isLeft()) {
          return Left(error);
        } else {
          var homeListModel = HomeListModel.fromJson(data);
          var homeListEntity = homeListModel.toEntity();
          var homeScreenQueryDtoEntityList =
              homeListEntity.result!.homeScreenQueryDto;
          return Right(homeScreenQueryDtoEntityList);
        }
      },
    );
  }

  @override
  Future<Either> getPersonnelList(PersonnelListParams? param) async {
    Either result = await sl<AuthApiService>().getPersonnelList(param!);
    return result.fold(
      (error) {
        return Left(error);
      },
      (data) async {
        return Right(data);
      },
    );
  }
}
