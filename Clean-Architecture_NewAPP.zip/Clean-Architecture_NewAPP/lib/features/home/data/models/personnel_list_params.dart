class PersonnelListParams {
  int? page;
  int? size;

  PersonnelListParams({
    this.page,
    this.size,
  });
}
