class HomeListParams {
  String? personnelId;
  String? startDate;
  String? endDate;
  bool? active;
  int? page;
  int? size;

  HomeListParams({
    this.personnelId,
    this.startDate,
    this.endDate,
    this.active,
    this.page,
    this.size,
  });
}
