import 'package:new_task_trackre/features/home/domain/entities/home_list.dart';

class HomeListModel {
  Result? result;
  OperationResult? operationResult;
  int? refId;
  int? id;
  bool? isOperationSuccessful;

  HomeListModel(
      {this.result,
      this.operationResult,
      this.refId,
      this.id,
      this.isOperationSuccessful});

  HomeListModel.fromJson(Map<String, dynamic> json) {
    result = json['result'] != null ? Result.fromJson(json['result']) : null;
    operationResult = json['operationResult'] != null
        ? OperationResult.fromJson(json['operationResult'])
        : null;
    refId = json['refId'];
    id = json['id'];
    isOperationSuccessful = json['isOperationSuccessful'];
  }

  Map<String, dynamic> toJson() => {
        'result': result != null ? result!.toJson() : null,
        'operationResult':
            operationResult != null ? operationResult!.toJson() : null,
        'refId': refId,
        'id': id,
        'isOperationSuccessful': isOperationSuccessful,
      };
}

extension HomeListModelX on HomeListModel {
  HomeListEntity toEntity() {
    return HomeListEntity(
      result: result?.toEntity(),
      operationResult: operationResult?.toEntity(),
      refId: refId,
      id: id,
      isOperationSuccessful: isOperationSuccessful,
    );
  }
}

extension ResultX on Result {
  ResultEntity toEntity() {
    return ResultEntity(
      homeScreenQueryDto:
          homeScrenQueryDto?.map((dto) => dto.toEntity()).toList(),
    );
  }
}

extension HomeScreenQueryDtoX on HomeScrenQueryDto {
  HomeScreenQueryDtoEntity toEntity() {
    return HomeScreenQueryDtoEntity(
      taskId: taskId,
      taskListId: taskListId,
      personnelId: personnelId,
      personnelName: personnelName,
      personnelSurname: personnelSurname,
      topAreaName: topAreaName,
      areaName: areaName,
      areaSubId: areaSubId,
      taskName: taskName,
      startDate: startDate,
      endDate: endDate,
      averageTime: averageTime,
      active: active,
      taskDescriptionId: taskDescriptionId,
    );
  }
}

extension OperationResultX on OperationResult {
  OperationResultEntity toEntity() {
    return OperationResultEntity(
      referenceId: referenceId,
      messageTitle: messageTitle,
      messageContent: messageContent,
      messageDetail: messageDetail,
      result: result,
    );
  }
}

class Result {
  List<HomeScrenQueryDto>? homeScrenQueryDto;

  Result({this.homeScrenQueryDto});

  Result.fromJson(Map<String, dynamic> json) {
    if (json['homeScrenQueryDto'] != null) {
      homeScrenQueryDto = <HomeScrenQueryDto>[];
      json['homeScrenQueryDto'].forEach((v) {
        homeScrenQueryDto!.add(HomeScrenQueryDto.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() => {
        'homeScrenQueryDto': homeScrenQueryDto != null
            ? homeScrenQueryDto!.map((v) => v.toJson()).toList()
            : null,
      };
}

class HomeScrenQueryDto {
  String? taskId;
  String? taskListId;
  String? personnelId;
  String? personnelName;
  String? personnelSurname;
  String? topAreaName;
  String? areaName;
  String? areaSubId;
  String? taskName;
  DateTime? startDate;
  DateTime? endDate;
  String? averageTime;
  bool? active;
  String? taskDescriptionId;

  HomeScrenQueryDto(
      {this.taskId,
      this.taskListId,
      this.personnelId,
      this.personnelName,
      this.personnelSurname,
      this.topAreaName,
      this.areaName,
      this.areaSubId,
      this.taskName,
      this.startDate,
      this.endDate,
      this.averageTime,
      this.active,
      this.taskDescriptionId});

  HomeScrenQueryDto.fromJson(Map<String, dynamic> json) {
    taskId = json['taskId'];
    taskListId = json['taskListId'];
    personnelId = json['personnelId'];
    personnelName = json['personnelName'];
    personnelSurname = json['personnelSurname'];
    topAreaName = json['topAreaName'];
    areaName = json['areaName'];
    areaSubId = json['areaSubId'];
    taskName = json['taskName'];
    startDate =
        json['startDate'] != null ? DateTime.tryParse(json['startDate']) : null;
    endDate =
        json['endDate'] != null ? DateTime.tryParse(json['endDate']) : null;
    averageTime = json['averageTime'];
    active = json['active'];
    taskDescriptionId = json['taskDescriptionId'];
  }

  Map<String, dynamic> toJson() => {
        'taskId': taskId,
        'taskListId': taskListId,
        'personnelId': personnelId,
        'personnelName': personnelName,
        'personnelSurname': personnelSurname,
        'topAreaName': topAreaName,
        'areaName': areaName,
        'areaSubId': areaSubId,
        'taskName': taskName,
        'startDate': startDate!.toIso8601String(),
        'endDate': endDate!.toIso8601String(),
        'averageTime': averageTime,
        'active': active,
        'taskDescriptionId': taskDescriptionId,
      };
}

class OperationResult {
  String? referenceId;
  String? messageTitle;
  String? messageContent;
  String? messageDetail;
  int? result;

  OperationResult(
      {this.referenceId,
      this.messageTitle,
      this.messageContent,
      this.messageDetail,
      this.result});

  OperationResult.fromJson(Map<String, dynamic> json) {
    referenceId = json['referenceId'];
    messageTitle = json['messageTitle'];
    messageContent = json['messageContent'];
    messageDetail = json['messageDetail'];
    result = json['result'];
  }

  Map<String, dynamic> toJson() => {
        'referenceId': referenceId,
        'messageTitle': messageTitle,
        'messageContent': messageContent,
        'messageDetail': messageDetail,
        'result': result,
      };
}
