import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/core/network/dio_client.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/data/models/personnel_list_params.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/sevice_locator.dart';

abstract class HomeApiService {
  Future<Either> signup(LoginReq userModel);
  Future<Either> getUserPermissions(String? userId);
  Future<Either> logginButton(LoginReq? loginUserModel);
  Future<Either> getUserRoles(String? userId);
  Future<Either> getPersonnelUserIdList(String? userId);
  Future<Either> getHomeList(HomeListParams? param);
  Future<Either> getPersonnelList(PersonnelListParams? param);
}

class HomeApiServiceImp extends HomeApiService {
  @override
  Future<Either> signup(LoginReq userModel) async {
    // try {
    //   var response =
    //       await sl<DioClient>().post(ApiUrls.register, data: userModel);
    //   return Right(response.data);
    return const Right("");
    // } on DioException catch (e) {
    //   return Left(e.response!.data["message"]);
    // }
  }

  @override
  Future<Either> getUserPermissions(String? userId) async {
    try {
      var response =
          await sl<DioClient>().get("${Environment.getUserPermissions}$userId");

      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }

  @override
  Future<Either> logginButton(LoginReq? loginUserModel) async {
    try {
      var response = await sl<DioClient>()
          .post("${Environment.authLogin}", data: json.encode(loginUserModel));

      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }

  @override
  Future<Either> getUserRoles(String? userId) async {
    try {
      var response =
          await sl<DioClient>().get("${Environment.getRolesToUser}/$userId");
      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }

  @override
  Future<Either> getPersonnelUserIdList(String? userId) async {
    try {
      var response = await sl<DioClient>()
          .get("${Environment.getPersonnelUserIdList}$userId");
      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }

  @override
  Future<Either> getHomeList(HomeListParams? param) async {
    try {
      var response = await sl<DioClient>().get(
        "${Environment.getHomeList}?PersonnelId=${param!.personnelId}&StartDate=${param.startDate}&EndDate=${param.endDate}&Active=${param.active}&Page=${param.page}&Size=${param.size}",
      );
      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }

  @override
  Future<Either> getPersonnelList(PersonnelListParams? param) async {
    try {
      var response = await sl<DioClient>().get(
        "${Environment.getPersonnelList}?Page=${param!.page}&Size=${param.size}",
      );
      return Right(response.data);
    } on DioException catch (e) {
      return Left(e.response!.data["message"]);
    }
  }
}
