import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/core/config/helper/logger.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_response.dart';
import 'package:new_task_trackre/features/loggin/data/models/qr_code_req.dart';
import 'package:shared_preferences/shared_preferences.dart';

abstract class HomeLocalService {
  Future<bool> isLoggedIn();
  Future logout();
  Future<bool> qrCodeReader(String? code);
  Future<bool> isThereBaseUrl();
  Future saveLoginResponseInfo(LoginResponseModel loginResponse);
  Future saveUserInfo(LoginReq loginResponse);
  Future savePermissions(dynamic data);
  Future saveUserRoles(dynamic data);
  Future savePersonnelUserIdList(dynamic data);
  Future<bool> isRoleValid(String? role);
}

class HomeLocalServiceImpl extends HomeLocalService {
  @override
  Future<bool> isLoggedIn() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var token = sharedPreferences.getString(Environment.accessToken);
    if (token == null || token.isEmpty || token == "") {
      return false;
    } else {
      return true;
    }
  }

  @override
  Future<Either> logout() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString(Environment.accessToken, "");
    return const Right(true);
  }

  @override
  Future<bool> qrCodeReader(String? code) async {
    if (code == null || code.isEmpty) {
      Loggers.error("Scanned QR code is null or empty");
      // return left("Scanned QR code is empty!");
      return false;
    }
    try {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var jsonObject = json.decode(code);
      var login = QrCodeReq.fromJson(jsonObject);
      Loggers.success("Parsed QR code: ${login.url}, ${login.userName}");
      sharedPreferences.setString(Environment.baseName, login.url!);
      sharedPreferences.setString(
          Environment.sabitKurumId, login.sabitKurumId.toString());

      // return const Right("Success");
      return true;
    } catch (e) {
      Loggers.error("Error parsing QR code: $e");
      // return left("Invalid QR code data!");
      return false;
    }
  }

  @override
  Future<bool> isThereBaseUrl() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    var baseName = sharedPreferences.getString(Environment.baseName);
    if (baseName == null || baseName.isEmpty || baseName == "") {
      return false;
    } else {
      return true;
    }
  }

  @override
  Future saveLoginResponseInfo(LoginResponseModel loginResponse) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString(
        Environment.accessToken, loginResponse.token!.accessToken!);
    sharedPreferences.setString(
        Environment.refreshToken, loginResponse.token!.refreshToken!);
    sharedPreferences.setString(
        Environment.expiration, "${loginResponse.token!.expiration!}");
    sharedPreferences.setString(Environment.userId, loginResponse.userId!);
    sharedPreferences.setString(
        Environment.customerId, loginResponse.customerId!);
    Loggers.warning("Token = ${loginResponse.token!.accessToken!}");
  }

  @override
  Future saveUserInfo(LoginReq loginResponse) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    sharedPreferences.setString(
        Environment.fakeName, loginResponse.usernameOrEmail!);
    sharedPreferences.setString(
        Environment.fakePassWord, loginResponse.password!);
  }

  @override
  Future savePermissions(dynamic data) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    String mapConverter = json.encode(data);
    sharedPreferences.setString(Environment.permissions, mapConverter);
  }

  @override
  Future saveUserRoles(dynamic data) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    String mapConverter = json.encode(data);
    sharedPreferences.setString(Environment.userRole, mapConverter);
  }

  @override
  Future savePersonnelUserIdList(dynamic data) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    String mapConverter = json.encode(data);
    sharedPreferences.setString(
        Environment.getPersonnelUserIdList, mapConverter);
  }

  @override
  Future<bool> isRoleValid(String? role) async {
    bool? access;
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();

    String? getPermissions =
        sharedPreferences.getString(Environment.permissions);
    // Loggers.warning("===============================================");
    // Loggers.warning("getPermissions = ${getPermissions.toString()}");
    // Loggers.warning("===============================================");
    Map<String, dynamic> permissionsMap = json.decode(getPermissions!);
    permissionsMap.forEach((key, value) {
      access = value.toString().contains(role!);
    });
    return access!;
  }
}
