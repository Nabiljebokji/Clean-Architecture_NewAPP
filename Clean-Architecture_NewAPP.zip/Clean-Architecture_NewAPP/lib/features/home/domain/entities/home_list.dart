class HomeListEntity {
  final ResultEntity? result;
  final OperationResultEntity? operationResult;
  final int? refId;
  final int? id;
  final bool? isOperationSuccessful;

  HomeListEntity({
    this.result,
    this.operationResult,
    this.refId,
    this.id,
    this.isOperationSuccessful,
  });
}

class ResultEntity {
  final List<HomeScreenQueryDtoEntity>? homeScreenQueryDto;

  ResultEntity({this.homeScreenQueryDto});
}

class HomeScreenQueryDtoEntity {
  final String? taskId;
  final String? taskListId;
  final String? personnelId;
  final String? personnelName;
  final String? personnelSurname;
  final String? topAreaName;
  final String? areaName;
  final String? areaSubId;
  final String? taskName;
  final DateTime? startDate;
  final DateTime? endDate;
  final String? averageTime;
  final bool? active;
  final String? taskDescriptionId;

  HomeScreenQueryDtoEntity({
    this.taskId,
    this.taskListId,
    this.personnelId,
    this.personnelName,
    this.personnelSurname,
    this.topAreaName,
    this.areaName,
    this.areaSubId,
    this.taskName,
    this.startDate,
    this.endDate,
    this.averageTime,
    this.active,
    this.taskDescriptionId,
  });
}

class OperationResultEntity {
  final String? referenceId;
  final String? messageTitle;
  final String? messageContent;
  final String? messageDetail;
  final int? result;

  OperationResultEntity({
    this.referenceId,
    this.messageTitle,
    this.messageContent,
    this.messageDetail,
    this.result,
  });
}
