import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/home/domain/repository/home.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class IsRoleValidUseCase implements UseCase<bool, String?> {
  @override
  Future<bool> call({String? param}) async {
    return sl<HomeRepository>().isRoleValid(param!);
  }
}
