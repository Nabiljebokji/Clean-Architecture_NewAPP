import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/domain/repository/home.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class GetHomeListUsecase implements UseCase<Either, HomeListParams?> {
  @override
  Future<Either> call({HomeListParams? param}) async {
    return sl<HomeRepository>().getHomeList(param!);
  }
}
