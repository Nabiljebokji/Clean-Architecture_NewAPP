import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/features/home/data/models/home_list_params.dart';
import 'package:new_task_trackre/features/home/data/models/personnel_list_params.dart';

abstract class HomeRepository {
  Future<bool> isRoleValid(String? role);
  Future<Either> getHomeList(HomeListParams? param);
  Future<Either> getPersonnelList(PersonnelListParams? param);
}
