// ignore_for_file: deprecated_member_use, use_key_in_widget_constructors
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:new_task_trackre/common/widgets/snack_bar/basic_snack_bar.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/core/config/helper/logger.dart';
import 'package:new_task_trackre/core/constants/colors/app_colors.dart';
import 'package:new_task_trackre/core/constants/images/app_images.dart';
import 'package:new_task_trackre/features/home/presentation/pages/home.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/login_button.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/is_password_visible/is_password_visible_cubit.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/login_button/login_button_cubit_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/login_button/login_button_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/qr_code_reader/qr_code_reader_cubit_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/qr_code_reader/qr_code_reader_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/remember_me/remember_me_cubit.dart';
import 'package:new_task_trackre/features/loggin/presentation/widgets/build_text_field.dart';
import 'package:new_task_trackre/features/loggin/presentation/widgets/loggin_button.dart';
import 'package:new_task_trackre/features/loggin/presentation/widgets/show_custom_dialog.dart';
import 'package:new_task_trackre/sevice_locator.dart';
import 'package:qr_bar_code_scanner_dialog/qr_bar_code_scanner_dialog.dart';

class LogginPage extends StatelessWidget {
  final TextEditingController userNameController = TextEditingController();
  final TextEditingController passWordController = TextEditingController();
  final TextEditingController baseNameUrlController = TextEditingController();
  final TextEditingController institutionidController = TextEditingController();
  final qrBarCodeScannerDialogPlugin = QrBarCodeScannerDialog();

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    return Scaffold(
      backgroundColor: AppColors.lightGrey,
      body: MultiBlocProvider(
        providers: [
          BlocProvider(create: (context) => RememberMeCubit()),
          BlocProvider(create: (context) => IsPasswordVisibleCubit()),
          BlocProvider(create: (context) => QrCodeReaderCubitState()),
          BlocProvider(create: (context) => LoginButtonCubitState()),
        ],
        child: MultiBlocListener(
          listeners: [
            BlocListener<QrCodeReaderCubitState, QrCodeReaderState>(
              listener: (context, state) {
                if (state is QrCodeSuccessState) {
                  Loggers.success("${state.successMessage.toString()}.");
                  var snackBar = customSnackBar(
                      context: context,
                      // title: "Basarli!.",
                      body: "${state.successMessage.toString()}.",
                      isErrorIcon: false);
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                }
                if (state is QrCodeFailureState) {
                  var snackBar = customSnackBar(
                      context: context,
                      title: "Hata!.",
                      body: "${state.errorMessage.toString()}.",
                      isErrorIcon: true);
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                }
              },
            ),
            BlocListener<LoginButtonCubitState, LoginButtonState>(
              listener: (context, state) {
                if (state is LoginButtonSuccessState) {
                  Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomePage(),
                      ));
                }
                if (state is LoginButtonFailureState) {
                  Loggers.error("error = ${state.errorMessage}");
                  var snackBar = customSnackBar(
                    context: context,
                    // title: "Hata!.",
                    body: "${state.errorMessage.toString()}.",
                    isErrorIcon: true,
                  );
                  ScaffoldMessenger.of(context).showSnackBar(snackBar);
                }
              },
            ),
          ],
          child: GestureDetector(
            onTap: () => FocusManager.instance.primaryFocus?.unfocus(),
            child: SingleChildScrollView(
              child: SizedBox(
                height: MediaQuery.of(context).size.height,
                child: Stack(
                  children: [
                    _buildLogoSection(context),
                    Positioned(
                      bottom: 0,
                      child: _buildLoginForm(context),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildLogoSection(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: MediaQuery.of(context).size.height * 0.1),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Column(
            children: [
              logoImage(),
              const SizedBox(height: 10),
              appName(),
            ],
          ),
        ],
      ),
    );
  }

  Widget logoImage() {
    return Image.asset(AppImages.logo, height: 80, width: 80);
  }

  Widget appName() {
    return const Text(
      "Görev Takip",
      style: TextStyle(
        color: AppColors.logoColor,
        fontSize: 25,
        fontWeight: FontWeight.w700,
      ),
    );
  }

  Widget _buildLoginForm(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.67,
      width: MediaQuery.of(context).size.width,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(40),
          topLeft: Radius.circular(40),
        ),
        color: AppColors.white,
        boxShadow: [
          BoxShadow(
            color: AppColors.logoColor,
            blurRadius: 0.9,
            spreadRadius: 0.6,
            blurStyle: BlurStyle.outer,
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildkDebugMode(context),
              _buildTwoTextFields(context),
              _buildRememberMe(context),
              _buildLoginButton(context),
              _buildFooter(context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildkDebugMode(BuildContext context) {
    return kDebugMode
        ? Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              IconButton(
                  alignment: Alignment.center,
                  onPressed: () {
                    showMaterialDialog(context);
                  },
                  icon: const Icon(
                    Icons.settings,
                    color: AppColors.logoColor,
                  )),
              const SizedBox(width: 8),
            ],
          )
        : const SizedBox(height: 25);
  }

  Widget _buildTwoTextFields(BuildContext context) {
    return Column(
      children: [
        buildTextField(
          controller: userNameController,
          hintText: "Kullanıcı Adı",
          icons: Icons.person,
        ),
        const SizedBox(height: 8),
        _buildPasswordField(context),
      ],
    );
  }

  Widget _buildPasswordField(BuildContext context) {
    return BlocBuilder<IsPasswordVisibleCubit, bool>(
      builder: (context, state) {
        return buildTextField(
          controller: passWordController,
          hintText: "Parola",
          icons: Icons.lock,
          obscureText: context.read<IsPasswordVisibleCubit>().isPasswordVisible,
          suffixIcon: IconButton(
            icon: Icon(
              context.read<IsPasswordVisibleCubit>().isPasswordVisible == false
                  ? Icons.visibility
                  : Icons.visibility_off,
            ),
            onPressed: () {
              bool getbool =
                  context.read<IsPasswordVisibleCubit>().isPasswordVisible;
              context.read<IsPasswordVisibleCubit>().onVisiblePressed(!getbool);
            },
          ),
        );
      },
    );
  }

  Widget _buildRememberMe(BuildContext context) {
    return BlocBuilder<RememberMeCubit, bool>(
      builder: (context, state) {
        return Padding(
          padding: EdgeInsets.symmetric(
              horizontal: MediaQuery.of(context).size.width * 0.15),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("Beni hatırla"),
              CupertinoSwitch(
                value: context.read<RememberMeCubit>().rememberMe,
                activeColor: AppColors.logoColor,
                onChanged: (bool value) {
                  context.read<RememberMeCubit>().onSwitchPressed(value);
                },
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildLoginButton(BuildContext context) {
    return Builder(builder: (context) {
      return LogginButton(
        onPressed: () {
          if (kDebugMode) {
            // userNameController.text = "huseyin.inanc";
            // passWordController.text = "K@rdelen+2024!";
            userNameController.text = Environment.fakeName;
            passWordController.text = Environment.fakePassWord;
          }
          context.read<LoginButtonCubitState>().excute(
              usecase: sl<LoginButtonUseCase>(),
              params: LoginReq(
                usernameOrEmail: userNameController.text,
                password: passWordController.text,
              ));
        },
        title: "Giriş Yap",
      );
    });
  }

  Widget _buildFooter(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  SizedBox(
                      height: 60,
                      width: 60,
                      child: SvgPicture.asset(AppImages.kardelenLogo,
                          color: const Color.fromARGB(255, 218, 16, 2))),
                  SizedBox(
                    height: 60,
                    width: 60,
                    child: SvgPicture.asset(AppImages.kardelenYazilim),
                  ),
                ],
              ),
              Builder(builder: (context) {
                return GestureDetector(
                  onTap: () {
                    qrBarCodeScannerDialogPlugin.getScannedQrBarCode(
                      context: context,
                      onCode: (code) {
                        context.read<QrCodeReaderCubitState>().scanQrCode(code);
                      },
                    );
                  },
                  child: Image.asset(
                    AppImages.qrCode,
                    height: 70,
                    width: 70,
                    alignment: Alignment.bottomCenter,
                  ),
                );
              }),
            ],
          ),
        ),
      ],
    );
  }

  showMaterialDialog(BuildContext context) {
    return showDialog(
      context: context,
      builder: (context) {
        return ShowCustomDialog(
          baseNameUrlController: baseNameUrlController,
          institutionidController: institutionidController,
        );
      },
    );
  }
}
