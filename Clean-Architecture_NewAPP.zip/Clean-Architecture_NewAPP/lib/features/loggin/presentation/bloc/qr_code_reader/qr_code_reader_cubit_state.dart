import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:new_task_trackre/features/loggin/domain/usecases/qr_code_reader.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/qr_code_reader/qr_code_reader_state.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class QrCodeReaderCubitState extends Cubit<QrCodeReaderState> {
  QrCodeReaderCubitState() : super(QrCodeInitialState());

  Future<void> scanQrCode(String? code) async {
    var isQrCodeScaned = await sl<QrCodeReaderUseCase>().call(param: code);

    if (isQrCodeScaned) {
      emit(QrCodeSuccessState(successMessage: "Başarılı"));
    } else {
      emit(QrCodeFailureState(errorMessage: "Geçersiz QR kodu"));
    }
  }
}
