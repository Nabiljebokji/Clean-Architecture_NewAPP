// ignore_for_file: public_member_api_docs, sort_constructors_first
abstract class QrCodeReaderState {}

class QrCodeInitialState extends QrCodeReaderState {}

class QrCodeSuccessState extends QrCodeReaderState {
  final String successMessage;
  QrCodeSuccessState({
    required this.successMessage,
  });
}

class QrCodeFailureState extends QrCodeReaderState {
  final String errorMessage;

  QrCodeFailureState({required this.errorMessage});
}
