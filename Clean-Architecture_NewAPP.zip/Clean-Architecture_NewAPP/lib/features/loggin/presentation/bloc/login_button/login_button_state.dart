abstract class LoginButtonState {}

class LoginButtonInitialState extends LoginButtonState {}

class LoginButtonLoadingState extends LoginButtonState {}

class LoginButtonSuccessState extends LoginButtonState {}

class LoginButtonFailureState extends LoginButtonState {
  final String errorMessage;

  LoginButtonFailureState({required this.errorMessage});
}
