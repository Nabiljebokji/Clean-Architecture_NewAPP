import 'package:dartz/dartz.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/login_button/login_button_state.dart';

class LoginButtonCubitState extends Cubit<LoginButtonState> {
  LoginButtonCubitState() : super(LoginButtonInitialState());

  Future<void> excute({dynamic params, required UseCase usecase}) async {
    emit(LoginButtonLoadingState());
    try {
      Either result = await usecase.call(param: params);

      result.fold((error) {
        emit(LoginButtonFailureState(errorMessage: error.toString()));
      }, (data) {
        emit(LoginButtonSuccessState());
      });
    } catch (e) {
      emit(LoginButtonFailureState(errorMessage: e.toString()));
    }
  }
}
