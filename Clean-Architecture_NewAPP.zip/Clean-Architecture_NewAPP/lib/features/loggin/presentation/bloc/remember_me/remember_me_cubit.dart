import 'package:flutter_bloc/flutter_bloc.dart';

class RememberMeCubit extends Cubit<bool> {
  RememberMeCubit() : super(false);

  bool rememberMe = false;

  void onSwitchPressed(bool isIt) {
    rememberMe = isIt;
    emit(isIt);
  }
}
