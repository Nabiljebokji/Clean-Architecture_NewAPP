import 'package:flutter_bloc/flutter_bloc.dart';

class IsPasswordVisibleCubit extends Cubit<bool> {
  IsPasswordVisibleCubit() : super(false);

  bool isPasswordVisible = false;

  void onVisiblePressed(bool isIt) {
    isPasswordVisible = isIt;
    emit(isIt);
  }
}
