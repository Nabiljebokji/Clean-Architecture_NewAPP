import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:new_task_trackre/core/constants/colors/app_colors.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/login_button/login_button_cubit_state.dart';
import 'package:new_task_trackre/features/loggin/presentation/bloc/login_button/login_button_state.dart';

class LogginButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String title;
  final double? height;
  final double? width;
  const LogginButton(
      {required this.onPressed,
      this.title = '',
      this.height,
      this.width,
      super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<LoginButtonCubitState, LoginButtonState>(
      builder: (context, state) {
        if (state is LoginButtonLoadingState) {
          return _loading(context);
        }
        return _initial(context);
      },
    );
  }

  Widget _loading(BuildContext context) {
    return ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.logoColor,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(15),
              bottomRight: Radius.circular(15),
            ),
          ),
          minimumSize: const Size(220, 50),
        ),
        child: const CircularProgressIndicator(
          color: Colors.white,
        ));
  }

  Widget _initial(BuildContext context) {
    return ElevatedButton(
      onPressed: onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.logoColor,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(15),
            bottomRight: Radius.circular(15),
          ),
        ),
        minimumSize: const Size(220, 50),
      ),
      child: Text(
        title.toString(),
        style: const TextStyle(color: Colors.white, fontSize: 20),
      ),
    );
  }
}
