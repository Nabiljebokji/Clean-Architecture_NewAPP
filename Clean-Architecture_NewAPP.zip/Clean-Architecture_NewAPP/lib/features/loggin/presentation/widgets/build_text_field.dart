// ignore_for_file: unused_element

import 'package:flutter/material.dart';
import 'package:new_task_trackre/core/constants/colors/app_colors.dart';

Widget buildTextField({
  IconData? icons,
  String? hintText,
  TextEditingController? controller,
  Widget? suffixIcon,
  bool? obscureText,
}) {
  return Padding(
    padding: const EdgeInsets.only(left: 20.0, right: 40, top: 10),
    child: Row(
      children: [
        Padding(
          padding: const EdgeInsets.all(10.0),
          child: Icon(
            icons,
            color: AppColors.logoColor,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Container(
            decoration: const BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: AppColors.logoColor,
                  blurRadius: 0.9,
                  spreadRadius: 0.9,
                  blurStyle: BlurStyle.outer,
                ),
              ],
              borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(15),
                  bottomRight: Radius.circular(15)),
              color: Colors.white,
            ),
            child: TextField(
              controller: controller,
              obscureText: obscureText ?? false,
              decoration: InputDecoration(
                hintText: hintText,
                border: const OutlineInputBorder(
                  borderRadius: BorderRadius.only(
                      bottomRight: Radius.circular(15),
                      topLeft: Radius.circular(15)),
                  borderSide: BorderSide.none,
                ),
                suffixIcon: suffixIcon,
                suffixIconColor: AppColors.logoColor,
              ),
            ),
          ),
        ),
      ],
    ),
  );
}
