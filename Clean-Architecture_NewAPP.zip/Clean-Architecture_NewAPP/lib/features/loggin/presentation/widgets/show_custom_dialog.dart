// ignore_for_file: public_member_api_docs, sort_constructors_first
// ignore_for_file: must_be_immutable

import 'package:flutter/material.dart';

import 'package:new_task_trackre/core/constants/colors/app_colors.dart';

class ShowCustomDialog extends StatelessWidget {
  TextEditingController? baseNameUrlController;
  TextEditingController? institutionidController;
  ShowCustomDialog({
    this.baseNameUrlController,
    this.institutionidController,
  }) : super();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                border: Border.all(
                  color: const Color.fromARGB(255, 213, 212, 212),
                  width: 1.0,
                ),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(196, 196, 196, .3),
                    blurRadius: 10,
                    offset: Offset(0, 10),
                  )
                ]),
            child: TextField(
              style: const TextStyle(color: Colors.black),
              controller: baseNameUrlController,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  errorBorder: InputBorder.none,
                  disabledBorder: InputBorder.none,
                  hintText: "API URL (http://123.456.7:123)",
                  hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7))),
            ),
          ),
          const SizedBox(height: 10),
          Container(
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.white,
                border: Border.all(
                    color: const Color.fromARGB(255, 213, 212, 212),
                    width: 1.0),
                boxShadow: const [
                  BoxShadow(
                    color: Color.fromRGBO(196, 196, 196, .3),
                    blurRadius: 10,
                    offset: Offset(0, 10),
                  )
                ]),
            child: TextField(
              style: const TextStyle(color: Colors.black),
              controller: institutionidController,
              decoration: InputDecoration(
                  border: InputBorder.none,
                  focusedBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  errorBorder: InputBorder.none,
                  disabledBorder: InputBorder.none,
                  hintText: " institution ID",
                  hintStyle: TextStyle(color: Colors.grey.withOpacity(0.7))),
            ),
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                child: const Text(
                  "Tamam",
                  style: TextStyle(color: AppColors.logoColor),
                ),
                onPressed: () {
                  Navigator.pop(context);
                },
              )
            ],
          ),
        ],
      ),
    );
  }
}
