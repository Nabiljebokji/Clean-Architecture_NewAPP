class UserEntity {
  String? usernameOrEmail;
  String? password;

  UserEntity({this.usernameOrEmail, this.password});
}
