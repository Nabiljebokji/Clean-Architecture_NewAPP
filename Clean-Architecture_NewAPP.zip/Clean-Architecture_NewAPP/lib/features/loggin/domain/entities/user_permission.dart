class UserPermissionsEntity {
  List<String>? permissions;

  UserPermissionsEntity({this.permissions});
}
