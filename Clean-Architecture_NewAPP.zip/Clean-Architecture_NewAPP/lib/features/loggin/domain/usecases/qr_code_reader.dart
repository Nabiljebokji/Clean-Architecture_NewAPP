import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class QrCodeReaderUseCase implements UseCase<bool, String?> {
  @override
  Future<bool> call({String? param}) async {
    return sl<AuthRepository>().qrCodeReader(param!);
  }
}
