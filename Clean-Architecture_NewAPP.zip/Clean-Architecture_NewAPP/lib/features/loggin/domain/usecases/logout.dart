import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class LogoutUseCase implements UseCase<Either, dynamic> {
  @override
  Future<Either> call({param}) async {
    return await sl<AuthRepository>().logout();
  }
}
