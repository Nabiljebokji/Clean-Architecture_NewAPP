// ignore_for_file: file_names

import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class SignUpUseCase implements UseCase<Either, LoginReq> {
  @override
  Future<Either> call({LoginReq? param}) async {
    return sl<AuthRepository>().signup(param!);
  }
}
