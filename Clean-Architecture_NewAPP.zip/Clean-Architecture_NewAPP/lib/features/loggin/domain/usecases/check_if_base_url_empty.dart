import 'package:new_task_trackre/core/usecase/usecase.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class CheckIfBaseUrlEmptyUseCase implements UseCase<bool, dynamic> {
  @override
  Future<bool> call({dynamic param}) async {
    return sl<AuthRepository>().isThereBaseUrl();
  }
}
