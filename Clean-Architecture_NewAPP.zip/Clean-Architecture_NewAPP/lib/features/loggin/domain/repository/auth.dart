import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';

abstract class AuthRepository {
  Future<Either> signup(LoginReq userModel);
  Future<bool> isLoggedin();
  Future<Either> logout();
  Future<bool> qrCodeReader(String? code);
  Future<Either> logginButton(LoginReq? loginUserModel);
  Future<bool> isThereBaseUrl();
  Future<Either> getUserPermissions(String? userId);
  Future<Either> getUserRoles(String? userId);
  Future<Either> getPersonnelUserIdList(String? userId);
}
