class LoginResponseModel {
  Token? token;
  String? userId;
  String? customerId;

  LoginResponseModel({this.token, this.userId, this.customerId});

  LoginResponseModel.fromJson(Map<String, dynamic> json) {
    token = json['token'] == null ? null : Token.fromJson(json['token']);
    userId = json['userId'] == null ? null : json["userId"];
    customerId = json['customerId'] == null ? null : json["customerId"];
  }

  Map<String, dynamic> toJson() => {
        'token': token == null ? null : token!.toJson(),
        'userId': userId,
        'customerId': customerId,
      };
}

class Token {
  String? accessToken;
  DateTime? expiration;
  String? refreshToken;

  Token({this.accessToken, this.expiration, this.refreshToken});

  Token.fromJson(Map<String, dynamic> json) {
    accessToken = json['accessToken'];
    expiration = json['expiration'] != null
        ? DateTime.tryParse(json['expiration'])
        : null;
    refreshToken = json['refreshToken'];
  }

  Map<String, dynamic> toJson() => {
        'accessToken': accessToken,
        'expiration': expiration!.toIso8601String(),
        'refreshToken': refreshToken,
      };
}
