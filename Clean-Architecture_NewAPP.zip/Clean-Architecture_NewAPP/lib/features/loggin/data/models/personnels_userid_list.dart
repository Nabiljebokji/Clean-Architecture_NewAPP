class PersonnelUserIdListModel {
  Result? result;
  OperationResult? operationResult;
  int? refId;
  int? id;
  bool? isOperationSuccessful;

  PersonnelUserIdListModel(
      {this.result,
      this.operationResult,
      this.refId,
      this.id,
      this.isOperationSuccessful});

  PersonnelUserIdListModel.fromJson(Map<String, dynamic> json) {
    result = json['result'] != null ? Result.fromJson(json['result']) : null;
    operationResult = json['operationResult'] != null
        ? OperationResult.fromJson(json['operationResult'])
        : null;
    refId = json['refId'];
    id = json['id'];
    isOperationSuccessful = json['isOperationSuccessful'];
  }

  Map<String, dynamic> toJson() => {
        'result': result != null ? result!.toJson() : null,
        'operationResult':
            operationResult != null ? operationResult!.toJson() : null,
        'refId': refId,
        'id': id,
        'isOperationSuccessful': isOperationSuccessful,
      };
}

class Result {
  List<TaskPersonnelListResponseDtos>? taskPersonnelListResponseDto;

  Result({this.taskPersonnelListResponseDto});

  Result.fromJson(Map<String, dynamic> json) {
    if (json['taskPersonnelListResponseDto'] != null) {
      taskPersonnelListResponseDto = <TaskPersonnelListResponseDtos>[];
      json['taskPersonnelListResponseDto'].forEach((v) {
        taskPersonnelListResponseDto!
            .add(TaskPersonnelListResponseDtos.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() => {
        'taskPersonnelListResponseDto': taskPersonnelListResponseDto != null
            ? taskPersonnelListResponseDto!.map((v) => v.toJson()).toList()
            : null,
      };
}

class TaskPersonnelListResponseDtos {
  String? name;
  String? surname;
  String? tcNo;
  String? gsm;
  String? email;
  String? address;
  String? provinces;
  String? districts;
  int? sex;
  bool? show;
  String? authuserid;
  String? provincesName;
  String? districtsName;
  String? id;

  TaskPersonnelListResponseDtos(
      {this.name,
      this.surname,
      this.tcNo,
      this.gsm,
      this.email,
      this.address,
      this.provinces,
      this.districts,
      this.sex,
      this.show,
      this.authuserid,
      this.provincesName,
      this.districtsName,
      this.id});

  TaskPersonnelListResponseDtos.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    surname = json['surname'];
    tcNo = json['tcNo'];
    gsm = json['gsm'];
    email = json['email'];
    address = json['address'];
    provinces = json['provinces'];
    districts = json['districts'];
    sex = json['sex'];
    show = json['show'];
    authuserid = json['authuserid'];
    provincesName = json['provinces_name'];
    districtsName = json['districts_name'];
    id = json['id'];
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'surname': surname,
        'tcNo': tcNo,
        'gsm': gsm,
        'email': email,
        'address': address,
        'provinces': provinces,
        'districts': districts,
        'sex': sex,
        'show': show,
        'authuserid': authuserid,
        'provinces_name': provincesName,
        'districts_name': districtsName,
        'id': id,
      };
}

class OperationResult {
  String? referenceId;
  String? messageTitle;
  String? messageContent;
  String? messageDetail;
  int? result;

  OperationResult(
      {this.referenceId,
      this.messageTitle,
      this.messageContent,
      this.messageDetail,
      this.result});

  OperationResult.fromJson(Map<String, dynamic> json) {
    referenceId = json['referenceId'];
    messageTitle = json['messageTitle'];
    messageContent = json['messageContent'];
    messageDetail = json['messageDetail'];
    result = json['result'];
  }

  Map<String, dynamic> toJson() => {
        'referenceId': referenceId,
        'messageTitle': messageTitle,
        'messageContent': messageContent,
        'messageDetail': messageDetail,
        'result': result,
      };
}
