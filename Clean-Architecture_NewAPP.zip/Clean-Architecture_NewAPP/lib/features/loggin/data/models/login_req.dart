import 'package:new_task_trackre/features/loggin/domain/entities/user.dart';

class LoginReq {
  String? usernameOrEmail;
  String? password;

  LoginReq({this.usernameOrEmail, this.password});

  LoginReq.fromJson(Map<String, dynamic> json) {
    usernameOrEmail = json['usernameOrEmail'];
    password = json['password'];
  }

  Map<String, dynamic> toJson() => {
        'usernameOrEmail': usernameOrEmail,
        'password': password,
      };
}

extension UserXModel on LoginReq {
  UserEntity toEntity() {
    return UserEntity(
      usernameOrEmail: usernameOrEmail,
      password: password,
    );
  }
}
