// ignore_for_file: file_names

class SignUpReqModel {
  final String email;
  final String password;
  final String username;

  SignUpReqModel(
      {required this.email, required this.password, required this.username});

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'email': email,
      'password': password,
      'username': username,
    };
  }
}
