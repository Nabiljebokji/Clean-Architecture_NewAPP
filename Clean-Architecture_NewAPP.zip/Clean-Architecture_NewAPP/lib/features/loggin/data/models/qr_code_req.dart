class QrCodeReq {
  QrCodeReq({this.url, this.sabitKurumId, this.userName});

  String? url;
  int? sabitKurumId;
  String? userName;

  factory QrCodeReq.fromJson(Map<String, dynamic> json) => QrCodeReq(
        url: json["url"],
        sabitKurumId: json["sabitKurumId"],
        userName: json["userName"],
      );
}
