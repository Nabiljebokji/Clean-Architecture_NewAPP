class UserRolesModel {
  List<String>? userRoles;

  UserRolesModel({this.userRoles});

  UserRolesModel.fromJson(Map<String, dynamic> json) {
    userRoles = json['userRoles'].cast<String>();
  }

  Map<String, dynamic> toJson() => {
        'userRoles': userRoles,
      };
}
