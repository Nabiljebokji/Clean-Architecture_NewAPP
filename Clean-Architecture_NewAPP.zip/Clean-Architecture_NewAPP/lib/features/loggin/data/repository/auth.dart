import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/config/helper/logger.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_response.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_api_service.dart';
import 'package:new_task_trackre/features/loggin/data/source/auth_local_service.dart';
import 'package:new_task_trackre/features/loggin/domain/repository/auth.dart';
import 'package:new_task_trackre/sevice_locator.dart';

class AuthRepositorImpl extends AuthRepository {
  @override
  Future<Either> signup(LoginReq userModel) async {
    // Either result = await sl<AuthApiService>().signup(userModel);

    // return result.fold(
    //   (error) {
    //     return left(error);
    //   },
    //   (data) async {
    //     Response response = data;
    //     SharedPreferences sharedPreferences =
    //         await SharedPreferences.getInstance();
    //     sharedPreferences.setString(
    //         ApiUrls.token, response.data["token"]["accessToken"]);
    //     sharedPreferences.setString(
    //         ApiUrls.expirationToken, response.data["token"]["expiration"]);
    //     sharedPreferences.setString(
    //         ApiUrls.refreshToken, response.data["token"]["refreshToken"]);
    //     sharedPreferences.setString(ApiUrls.userId, response.data["userId"]);
    //     sharedPreferences.setString(
    //         ApiUrls.customerId, response.data["customerId"]);
    // return Right(response);
    return const Right("response");
    //   },
    // );
  }

  @override
  Future<bool> isLoggedin() async {
    return await sl<AuthLocalService>().isLoggedIn();
  }

  @override
  Future<Either> logout() async {
    return await sl<AuthLocalService>().logout();
  }

  @override
  Future<bool> qrCodeReader(String? code) async {
    return await sl<AuthLocalService>().qrCodeReader(code);
  }

  @override
  Future<Either> logginButton(LoginReq? loginUserModel) async {
    bool isThereBaseUrl = await sl<AuthLocalService>().isThereBaseUrl();
    if (isThereBaseUrl) {
      Either result = await sl<AuthApiService>().logginButton(loginUserModel);

      return result.fold((error) {
        return Left(error);
      }, (data) async {
        await sl<AuthLocalService>().saveUserInfo(loginUserModel!);

        await sl<AuthLocalService>()
            .saveLoginResponseInfo(LoginResponseModel.fromJson(data));
        Either error =
            await getUserPermissions(LoginResponseModel.fromJson(data).userId);
        Either error2 =
            await getUserRoles(LoginResponseModel.fromJson(data).userId);
        Either error3 = await getPersonnelUserIdList(
            LoginResponseModel.fromJson(data).userId);

        if (error.isLeft()) {
          return Left(error);
        }
        if (error2.isLeft()) {
          return Left(error2);
        }
        if (error3.isLeft()) {
          return Left(error3);
        } else {
          Loggers.success("GG");
          return Right(data);
        }
      });
    } else {
      return const Left("Lütfen QR kodunu tarayın");
    }
  }

  @override
  Future<Either> getUserPermissions(String? userId) async {
    Either result = await sl<AuthApiService>().getUserPermissions(userId);
    return result.fold(
      (error) {
        return Left(error);
      },
      (data) async {
        return Right(await sl<AuthLocalService>().savePermissions(data));
      },
    );
  }

  @override
  Future<Either> getUserRoles(String? userId) async {
    Either result = await sl<AuthApiService>().getUserRoles(userId);
    return result.fold(
      (error) {
        return Left(error);
      },
      (data) async {
        return Right(await sl<AuthLocalService>().saveUserRoles(data));
      },
    );
  }

  @override
  Future<bool> isThereBaseUrl() {
    return sl<AuthLocalService>().isThereBaseUrl();
  }

  @override
  Future<Either> getPersonnelUserIdList(String? userId) async {
    Either result = await sl<AuthApiService>().getPersonnelUserIdList(userId);
    return result.fold(
      (error) {
        return Left(error);
      },
      (data) async {
        return Right(
            await sl<AuthLocalService>().savePersonnelUserIdList(data));
      },
    );
  }
}
