import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:new_task_trackre/core/cache/cache_helper.dart';
import 'package:new_task_trackre/core/config/enviroment/environment.dart';
import 'package:new_task_trackre/core/config/helper/logger.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_req.dart';
import 'package:new_task_trackre/features/loggin/data/models/login_response.dart';
import 'package:new_task_trackre/features/loggin/data/models/qr_code_req.dart';
import 'package:new_task_trackre/sevice_locator.dart';
import 'package:shared_preferences/shared_preferences.dart';

abstract class AuthLocalService {
  Future<bool> isLoggedIn();
  Future logout();
  Future<bool> qrCodeReader(String? code);
  Future<bool> isThereBaseUrl();
  Future saveLoginResponseInfo(LoginResponseModel loginResponse);
  Future saveUserInfo(LoginReq loginResponse);
  Future savePermissions(dynamic data);
  Future saveUserRoles(dynamic data);
  Future savePersonnelUserIdList(dynamic data);
  Future<bool> isRoleValid(String? role);
}

class AuthLocalServiceImpl extends AuthLocalService {
  @override
  Future<bool> isLoggedIn() async {
    var token = sl<CacheHelper>().getData(key: Environment.accessToken);
    if (token == null || token.isEmpty || token == "") {
      return false;
    } else {
      return true;
    }
  }

  @override
  Future<Either> logout() async {
    sl<CacheHelper>().saveData(key: Environment.accessToken, value: "");
    return const Right(true);
  }

  @override
  Future<bool> qrCodeReader(String? code) async {
    if (code == null || code.isEmpty) {
      Logger.error("Scanned QR code is null or empty");
      // return left("Scanned QR code is empty!");
      return false;
    }
    try {
      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      var jsonObject = json.decode(code);
      var login = QrCodeReq.fromJson(jsonObject);
      Logger.success("Parsed QR code: ${login.url}, ${login.userName}");
      sl<CacheHelper>().saveData(key: Environment.baseName, value: login.url!);
      sl<CacheHelper>().saveData(
          key: Environment.sabitKurumId, value: login.sabitKurumId.toString());

      // return const Right("Success");
      return true;
    } catch (e) {
      Logger.error("Error parsing QR code: $e");
      // return left("Invalid QR code data!");
      return false;
    }
  }

  @override
  Future<bool> isThereBaseUrl() async {
    var baseName = sl<CacheHelper>().getData(key: Environment.baseName);
    if (baseName == null || baseName.isEmpty || baseName == "") {
      return false;
    } else {
      return true;
    }
  }

  @override
  Future saveLoginResponseInfo(LoginResponseModel loginResponse) async {
    sl<CacheHelper>().saveData(
        key: Environment.accessToken, value: loginResponse.token!.accessToken!);
    sl<CacheHelper>().saveData(
        key: Environment.refreshToken,
        value: loginResponse.token!.refreshToken!);
    sl<CacheHelper>().saveData(
        key: Environment.expiration,
        value: "${loginResponse.token!.expiration!}");
    sl<CacheHelper>()
        .saveData(key: Environment.userId, value: loginResponse.userId!);
    sl<CacheHelper>().saveData(
        key: Environment.customerId, value: loginResponse.customerId!);
    Logger.warning("Token = ${loginResponse.token!.accessToken!}");
  }

  @override
  Future saveUserInfo(LoginReq loginResponse) async {
    sl<CacheHelper>().saveData(
        key: Environment.fakeName, value: loginResponse.usernameOrEmail!);
    sl<CacheHelper>().saveData(
        key: Environment.fakePassWord, value: loginResponse.password!);
  }

  @override
  Future savePermissions(dynamic data) async {
    String mapConverter = json.encode(data);
    sl<CacheHelper>()
        .saveData(key: Environment.permissions, value: mapConverter);
  }

  @override
  Future saveUserRoles(dynamic data) async {
    String mapConverter = json.encode(data);
    sl<CacheHelper>().saveData(key: Environment.userRole, value: mapConverter);
  }

  @override
  Future savePersonnelUserIdList(dynamic data) async {
    String mapConverter = json.encode(data);
    sl<CacheHelper>()
        .saveData(key: Environment.getPersonnelUserIdList, value: mapConverter);
  }

  @override
  Future<bool> isRoleValid(String? role) async {
    bool? access;

    String? getPermissions =
        sl<CacheHelper>().getData(key: Environment.permissions);
    // Loggers.warning("===============================================");
    // Loggers.warning("getPermissions = ${getPermissions.toString()}");
    // Loggers.warning("===============================================");
    Map<String, dynamic> permissionsMap = json.decode(getPermissions!);
    permissionsMap.forEach((key, value) {
      access = value.toString().contains(role!);
    });
    return access!;
  }
}
