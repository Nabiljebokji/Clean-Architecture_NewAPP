package com.example.new_task_trackre

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
